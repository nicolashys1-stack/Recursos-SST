# Recursos SST - Plataforma Web

Plataforma profesional de Seguridad e Higiene en el Trabajo para @sst.nicosilveyra

## Identidad Visual
- Base: #0a0a0a / #1a1a1a
- Acento: #FFD60A (amarillo seguridad)
- Tipografía: Inter / Manrope

## Estructura
- index.html -> Plataforma completa MVP (React + Tailwind CDN)
- /assets -> (agregar logos, imágenes)
- /docs -> Documentación

## Cómo usar
1. Abrí index.html en navegador para preview local
2. Subí a Vercel: drag & drop de la carpeta
3. Conectá dominio recursossst.com.ar

## Funcionalidades MVP
- Buscador + filtros (categoría, sector, tipo, gratis/pago)
- Biblioteca SST
- Tienda con carrito y checkout Mercado Pago (mock)
- Secciones: Checklists, Plantillas, Legislación, Sectores, Aprender
- Responsive mobile-first

## Próximos pasos
- [ ] Integrar Mercado Pago real
- [ ] Panel admin sin código
- [ ] Conectar NIC Argentina dominio

Creado con Meta AI para Nicolás Silveyra - Recursos SST
Instagram: @sst.nicosilveyra
